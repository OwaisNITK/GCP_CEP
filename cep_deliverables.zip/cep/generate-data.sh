#!/bin/bash
echo "Data Loading Started at $(date +"%T")"
CURRENT_DATE=$(date +"%Y-%m-%d")
CURRENT_TIME=$(date +"%H-%M-%S")

# Resolving File Path
FILE_NAME="$(date +"%m-%d-%Y")"
COVID19_INPUT_DIR="/home/owais_nitk/cep/input"
LOCAL_FILE_PATH="${COVID19_INPUT_DIR}/${FILE_NAME}.csv"
COVID19_PROCESSED_DIR="/home/owais_nitk/cep/processed"
PROCESSED_FILE_NAME="${FILE_NAME}_${CURRENT_TIME}.csv"
PROCESSED_FILE_PATH="${COVID19_PROCESSED_DIR}/${PROCESSED_FILE_NAME}"
GENERATOR_JAR_PATH="/home/owais_nitk/cep/datagenerator"
HDFS_FILE_PATH="/csse_covid_19_daily_reports"

# Generate File For Current Data at Input Directory
java -jar ${GENERATOR_JAR_PATH}/Covid19DataGenerator.jar ${CURRENT_DATE} ${COVID19_INPUT_DIR}/


# Validating Existence of Local File
if [ -f "$LOCAL_FILE_PATH" ]; then
	        echo "Validation Successful for LOCAL FILE : $LOCAL_FILE_PATH"
	else
		        echo "ERROR: File Doesn't Exist at the following path : $LOCAL_FILE_PATH"
				echo "Please Ensure that the file exist with valid read permissions"
				        exit 1
				fi

# Validating Existence of HDFS File
hdfs dfs -test -e $HDFS_FILE_PATH 
if [ $? -eq 0 ]; then
		echo "Validation Successful for HDFS DIRECTORY : $HDFS_FILE_PATH"
	else
			echo "ERROR : HDFS Directory Doesnt Exist at the following path : $HDFS_FILE_PATH"
				echo "Please Ensure that the directory exist with valid write permissions"
					exit 1
				fi

# Command to Load Data from Local File System to HDFS
hdfs dfs -put $LOCAL_FILE_PATH $HDFS_FILE_PATH/

# Validating Data Load over HDFS
hdfs dfs -test -e $HDFS_FILE_PATH/$FILE_NAME.csv
if [ $? -eq 0 ]; then
	        echo "File Successful loaded into HDFS DIRECTORY : $HDFS_FILE_PATH/$FILE_NAME.csv"
			mv $LOCAL_FILE_PATH $PROCESSED_FILE_PATH
		else
			        echo "ERROR : File could not be loaded into the HDFS Directory at the following path : $HDFS_FILE_PATH/$FILE_NAME.csv"
				        echo "Please Ensure that the directory exist with valid write permissions"
				fi  

echo "Data Loading Finished at $(date +"%T")"
