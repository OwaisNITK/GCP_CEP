#!/bin/bash
role="$(/usr/share/google/get_metadata_value attributes/dataproc-role)"
NODE_NAME="$(/usr/share/google/get_metadata_value name)"
if [[ "${role}" == 'Master' && "${NODE_NAME}" =~ ^.*(-m|-m-0)$ ]]; then
    gsutil mb -p cep-gcp-g14 -c STANDARD -l ASIA-EAST1 gs://gcp-cep-test-bucket/
fi
