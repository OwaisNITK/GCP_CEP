# Create dataproc cluster on cep-network
gcloud deployment-manager deployments create cep-cluster-deployment --config=/home/owais_nitk/cep/template/imp-cep-dev-dataproc-deployment-manager-template.yml 

#2. Verify DataUpdate on bucket


#3. Delete dataproc cluster on cep-network
gcloud deployment-manager deployments delete cep-cluster-deployment

# Move Data From Inpur Directory To Processed Directory of HDFS
hadoop dfs -mv /csse_covid_19_daily_reports/* /migrated/
